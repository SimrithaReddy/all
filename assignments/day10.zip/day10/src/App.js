import React,{useState} from "react";
import "./App.css"
import QRCode from 'qrcode.react';

const Assignment9 = () => {
  const [name, setName]=useState("Hello World");
	return (
		<>
		<div>
      <section><input type="text" onChange={(e)=>setName(e.target.value)}></input></section>
    <QRCode value={name}/>
    </div>
		</>
	)
};

export default Assignment9;
