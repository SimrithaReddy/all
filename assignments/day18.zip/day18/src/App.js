import React,{ useState } from "react";
import questions from "./q";
import "./App.css"

const Day88=()=>{
  const [question, setQuetion] = useState(0);
	const [score, setScore] = useState(0);

	const handleAnswer = (e,check) => {
    e.preventDefault();
		if(check) setScore(score + 1);
    setQuetion(question + 1);
	};

	return (
		<>
    <div className='quiz'>
			{question+1>questions.length ? (
        <>You scored {score} out of {questions.length}</>):
        (
        <>
        <div className='container'>
          <h2>Question {question + 1}/{questions.length}</h2>
          <h2>{questions[question].question}</h2>
        </div>
        <div className='options'>
          {questions[question].options.map((option,i) => (
            <button key={i} onClick={(e) => handleAnswer(e,option.check)}>{option.a}</button>
          ))}
        </div>
      </>
			)}
    </div>
		</>
	);
}

export default Day88;
