const questions = [
    {
        question: 'What is the capital of India?',
        options: [
            { a: 'Mumbai', check: false },
            { a: 'Haryana', check: false },
            { a: 'New Delhi', check: true },
            { a: 'Hyderabad', check: false },
        ],
    },
    {
        question: 'What is the capital of Telangana?',
        options: [
            { a: 'Nizamabad', check: false },
            { a: 'Khammam', check: false },
            { a: 'Vizag', check: false },
            { a: 'Hyderabad', check: true },
        ],
    },
    {
        question: 'Which original song in 2023 won Oscars Award?',
        options: [
            { a: 'Baby', check: false },
            { a: 'Naatu', check: true },
            { a: 'Rains', check: false },
            { a: 'Holding', check: false },
        ],
    }
];

module.exports=questions;