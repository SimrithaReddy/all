import { useState } from 'react';
import './App.css';

function App() {
  const [temp, settemp] = useState(10);
  const [arr, setarr] = useState([175,226,243])
  const [bg,setbg]=useState('rgb(175, 226, 243)')
  const handlePlus=(e)=>{
    e.preventDefault();
    settemp(temp+1);
    setarr([arr[0]-2,arr[1]+2,arr[2]-2])
    setbg(`rgb(${arr[0]}, ${arr[1]}, ${arr[2]})`)
  }
  const handleMinus=(e)=>{
    e.preventDefault();
    setarr([arr[0]+2,arr[1]+2,arr[2]-2])
    settemp(temp-1)
    setbg(`rgb(${arr[0]}, ${arr[1]}, ${arr[2]})`)
  }
  return (
    <div className="App">
      <div className='container' >
      <div id='circle' style={{backgroundColor:bg}}>
        {temp}C
      </div>
      <div className='flex'>
        <div className='circle-1' onClick={(e)=>handlePlus(e)}>+</div>
        <div className='circle-1' onClick={(e)=>handleMinus(e)}>-</div>
      </div>
      </div>
    </div>
  );
}

export default App;
