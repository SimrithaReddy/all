import React, {useState} from "react";
import "./styles/form.css"

const FormValidationASsignment8 = () => {
  let [via,setVia]=useState(false);
  const [userForm, setUserForm] = useState({name:"",age:"",gender:"", occupation:"none", isCool:via});

  return (
    <div id="main">
      <form className="form-main">
        <p style={{color:"black",fontWeight:"bold",marginBottom:"20px"}}>{JSON.stringify(userForm)}</p>
        <section className="gap">
        <label htmlFor='name'><b>Name:</b></label><br></br>
        <section>
        <input
        type="text" 
        data-testid = 'name'
        onChange={(event)=> {setUserForm({...userForm, name: event.target.value})}}>
        </input>
        </section>
        </section>

        <section className="gap">
        <label htmlFor='name'><b>Age:</b></label><br></br>
        <section>
        <input
        type="number" 
        data-testid = 'name'
        onChange={(event)=> {setUserForm({...userForm, age: event.target.value})}}>
        </input>
        </section>
        </section>

        <section className="gap">
        <label htmlFor='name'><b>Gender:</b></label><br></br>
<select name="cars" id="name"
 onChange={(event)=> {setUserForm({...userForm, gender: event.target.value})}}>
  <option value="">--SELECT</option>
  <option value="male">male</option>
  <option value="female">female</option>
  <option value="others">others</option>
</select>
        </section>

        <section className="gap" style={{marginTop:"20px"}}>
        <label htmlFor='name'><b>Occupation:</b></label><br></br>
<select name="cars" id="name"
 onChange={(event)=> {setUserForm({...userForm, occupation: event.target.value})}}>
  <option value="">--SELECT</option>
  <option value="frontend">frontend</option>
  <option value="backend">backend</option>
  <option value="fullStack">fullStack</option>
</select>
        </section>

        <section className="gap" style={{marginTop:"25px"}}>
<h5>Are you Cool?</h5>
<input type="checkbox" id="cool" name="cool" value="cool" onChange={()=>setVia(!via)}/>
<label htmlFor="cool">OfCourse!I'm Cool</label>
        </section>
      </form>
    </div>
  )
}
export default FormValidationASsignment8;


