import React, {useEffect, useState} from "react";
import "./styles/form.css"

const FormValidationASsignment8 = () => {
  const [userForm, setUserForm] = useState({username:"" ,lastname:"", email:""});
  const [formErrors,setErrors] = useState({});
  const [sub, setsub] = useState(false)
  const [head, sethead] = useState("")

  const handleChange = (e) =>{
    e.preventDefault();
    setErrors(Validate(userForm));
    setsub(true)
  }

  useEffect(()=>{
    if(Object.keys(formErrors).length!==0){
      setsub(false);
      sethead("")
    }
    if(Object.keys(formErrors).length===0 && sub){
      sethead("Success!Thank you for registering.")
    }
  },[formErrors])

  const Validate = (userForm) =>{
    const errors = {};
    const regex_email = /[a-zA-Z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,8}(.[a-z{2,8}])?/g;
    const regex = /^[a-zA-Z0-9\s]*$/g   
    if(userForm.username === "" || userForm.email ===  "" || userForm.password === ""){
      errors.main = "All fields are mandatory"          
    }else if(!regex.test(userForm.username)){
      errors.username = "Name is not alphanumeric"
    }else if(!regex_email.test(userForm.email)){
      errors.email = "Email must contain @ ."
    }
    return errors;
  }


  return (
    <div id="main">
      <form className="form-main">
        <h1 className="m">{head}</h1>
        <p style={{color:'red'}}>{formErrors.main}</p>
        <section className="gap">
        <label htmlFor='name'><b>Firstname:</b></label>
        <section>
        <input
        type="text" 
        data-testid = 'name'
        onChange={(event)=> {setUserForm({...userForm, username: event.target.value})}}>
        </input>
        </section>
        <p style={{color:'red'}}>{formErrors.username}</p>
        </section>

        <section className="gap">
        <label htmlFor='name'><b>Lastname:</b></label>
        <section>
        <input
        type="text" 
        data-testid = 'name'
        onChange={(event)=> {setUserForm({...userForm, lastname: event.target.value})}}>
        </input>
        </section>
        <p style={{color:'red'}}>{formErrors.username}</p>
        </section>

        <section className="gap">
        <label htmlFor='email'><b>Email:</b></label>
        <section>
        <input 
        type="email" 
        data-testid = 'email' 
        onChange={(event)=> {setUserForm({...userForm, email: event.target.value})}}>
        </input>
        </section>
        <p style={{color:'red'}}>{formErrors.email}</p>
        </section>

        <section className="gap">
        <input 
        type="button" 
        data-testid = 'submit'  
        value="Register" 
        onClick={handleChange}>
        </input>
        </section>
      </form>
    </div>
  )
}
export default FormValidationASsignment8;


