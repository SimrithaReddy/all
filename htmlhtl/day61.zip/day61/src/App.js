import "react-responsive-carousel/lib/styles/carousel.min.css"; // requires a loader
import { Carousel } from 'react-responsive-carousel';
import './App.css';

function App() {
  return (
    <div className="App">
      <Carousel>
                <div>
                    <img alt="Legend 1" height="400px" width="400px"
                    src="https://lh3.googleusercontent.com/hwau7OVWx96XaME5KpRuJ0I_MscrerK6SbRH1UwYHYaxIDQQtn7RZK02LDSfBzCreidFgDsJeXyqDct6EZiH6vsV=w640-h400-e365-rj-sc0x00ffffff" />
                    <p className="legend">Legend 1</p>
                </div>
                <div>
                    <img  alt="Legend 1" height="400px" width="400px"
                    src="https://www.generatormix.com/images/thumbs/random-image-generator.jpg" />
                    <p className="legend">Legend 2</p>
                </div>
                <div>
                    <img  alt="Legend 1" height="400px" width="400px"
                    src="https://images.unsplash.com/photo-1493612276216-ee3925520721?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8cmFuZG9tfGVufDB8fDB8fA%3D%3D&w=1000&q=80" />
                    <p className="legend">Legend 3</p>
                </div>
                <div>
                    <img  alt="Legend 1" height="400px" width="400px"
                    src="https://media.istockphoto.com/id/95442265/photo/lottery.jpg?b=1&s=170667a&w=0&k=20&c=7wyE7vy_TEGthZpiHYI8cyItBwlUgaA0yyVVkg9GT5U=" />
                    <p className="legend">Legend 4</p>
                </div>
            </Carousel>
    </div>
  );
}

export default App;
